import com.relevantcodes.extentreports.ExtentReports;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ChromeTestDemo {



    public static String DATE(){
        Date dt=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        File file=new File("bin/screencapture/"+sdf.format(dt));
        if(!file.exists()){
            file.mkdir();
        }
        return sdf.format(dt);
    }
    public static String date = ChromeTestDemo.DATE();

    public static ExtentReports extent = new ExtentReports("bin/report/"+date+"Report.html", true);

    public static void main(String[] args) {
        Case1_Negative testCase1Negative = new Case1_Negative();
        Case1_Positive testCase1Positive = new Case1_Positive();
        Case2 testCase2 = new Case2();
        Case3 testCase3 = new Case3();
        try {
            testCase1Negative.TestCase1_Negative();
            testCase1Positive.TestCase1_Positive();
            testCase2.TestCase2();
            testCase3.TestCase3();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}