import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;


public class Case1_Positive {

    public ExtentTest test;

    public void TestCase1_Positive() throws InterruptedException {
        Date dt=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        String date=sdf.format(new Date());
        try {
            System.setProperty("webdriver.chrome.driver","/Users/wency/Desktop/chromedriver");
            WebDriver driver = new ChromeDriver();
            //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.get("https://www.amazon.com/");
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Positive_OpenAmazon","bin/screencapture/","jpg");

            WebElement searchBox=driver.findElement(By.linkText("Sign in"));
            searchBox.click();
            searchBox=driver.findElement(By.linkText("Create your Amazon account"));
            searchBox.click();
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Positive_OpenSignIn","bin/screencapture/","jpg");

            WebElement input_name = driver.findElement(By.name("customerName"));
            input_name.clear();
            input_name.sendKeys("Jing");//input name
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Positive_InputName","bin/screencapture/","jpg");

            WebElement input_email = driver.findElement(By.name("email"));
            input_email.clear();
            input_email.sendKeys("Jing"+date+"@gmail.com");//input name
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Positive_InputEmail","bin/screencapture/","jpg");


            WebElement input_pw = driver.findElement(By.name("password"));
            input_pw.sendKeys("12345678");//input password
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Positive_InputPassword","bin/screencapture/","jpg");


            WebElement reinput_pw = driver.findElement(By.name("passwordCheck"));
            reinput_pw.sendKeys("12345678");//input password
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Positive_PasswordCheck","bin/screencapture/","jpg");

            String urlBefore = driver.getCurrentUrl();
            driver.findElement(By.id("continue")).click();
            String urlAfter = driver.getCurrentUrl();
            assertFalse(urlAfter == urlBefore);
            test = ChromeTestDemo.extent.startTest("TestCase1_Positive");
            if(!urlAfter.equals(urlBefore)){
                test.log(LogStatus.PASS, "The Website completed registration.");
                CaptureScreen.cutPic("Case1_Positive_Success","bin/screencapture/","jpg");

                String[][] data = {
                        { "Expected", "Actual"},
                        { "Success Registration", "Success Registration"}

                };
                Markup m = MarkupHelper.createTable(data);
                System.out.println(m.getMarkup());
                test.log(LogStatus.PASS, "<table><tr><td style=\"font-weight:bold\">Expected</td><td style=\"font-weight:bold\">Actual</td></tr><tr><td>Success Registration</td><td>Success Registration</td></tr></table>");

            }
            else{
                test.log(LogStatus.FAIL, "Website fail to complete the registration");
            }
            ChromeTestDemo.extent.endTest(test);
            ChromeTestDemo.extent.flush();
            Thread.sleep(2000);
            driver.quit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
