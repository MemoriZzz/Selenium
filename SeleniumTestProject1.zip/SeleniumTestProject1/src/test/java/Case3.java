import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.Assert.assertFalse;


public class Case3 {
    public static ExtentReports extent;
    public ExtentTest test;

    public void TestCase3() throws InterruptedException {
        Date dt=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        String date=sdf.format(dt);
        try {
            System.setProperty("webdriver.chrome.driver","/Users/wency/Desktop/chromedriver");
            WebDriver driver = new ChromeDriver();
            //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.get("https://www.amazon.com/");
            Thread.sleep(300);
            CaptureScreen.cutPic("Case3_OpenAmazon","bin/screencapture/","jpg");

            WebElement searchBox=driver.findElement(By.linkText("Sign in"));
            searchBox.click();
            Thread.sleep(300);
            CaptureScreen.cutPic("Case3_OpenSignIn","bin/screencapture/","jpg");

            WebElement input_email = driver.findElement(By.name("email"));
            input_email.clear();
            input_email.sendKeys("yangwency1@gmail.com");//input name
            Thread.sleep(300);
            CaptureScreen.cutPic("Case3_InputEmail","bin/screencapture/","jpg");

            WebElement input_pw = driver.findElement(By.name("password"));
            input_pw.sendKeys("Aa11111111");//input password
            Thread.sleep(300);
            CaptureScreen.cutPic("Case3_Password","bin/screencapture/","jpg");

            driver.findElement(By.id("signInSubmit")).click();
            Thread.sleep(300);

            searchBox=driver.findElement(By.name("field-keywords"));
            searchBox.clear();
            searchBox.sendKeys("bed");
            Thread.sleep(300);
            CaptureScreen.cutPic("Case3_SearchInput","bin/screencapture/","jpg");

            driver.findElement(By.className("nav-input")).click();
            Thread.sleep(300);
            CaptureScreen.cutPic("Case3_SearchResult","bin/screencapture/","jpg");

            driver.findElement((By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[3]/div[1]/div[2]/div/div/div/div/div/div[2]/div[1]/div/div/span/a/div/img"))).click();
            Thread.sleep(300);
            CaptureScreen.cutPic("Case3_ChooseItem","bin/screencapture/","jpg");

            driver.findElement(By.id("add-to-cart-button")).click();
            Thread.sleep(300);
            CaptureScreen.cutPic("Case3_AddtoCart","bin/screencapture/","jpg");

            String urlBefore = driver.getCurrentUrl();

            Thread.sleep(5000);

            Boolean isPresent = driver.findElements(By.xpath("//*[@id=\"attach-sidesheet-checkout-button\"]/span/input")).size() > 0;

            Boolean isRecommended = driver.findElements((By.xpath("//*[@id=\"attachSiNoCoverage-announce\"]"))).size()>0;
            if(isRecommended == true){
                driver.findElement(By.xpath("//*[@id=\"attachSiNoCoverage-announce\"]")).click();
                Thread.sleep(5000);

                //wait.until( ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"attachSiNoCoverage-announce\"]")));
                driver.findElement(By.xpath("//*[@id=\"attach-sidesheet-checkout-button\"]/span/input")).click();


            }
            else {

                if (isPresent == false) {
                    driver.findElement(By.id("siNoCoverage-announce")).click();
                    Thread.sleep(300);
                    driver.findElement(By.xpath("//*[@id=\"hlb-ptc-btn-native\"]")).click();

                }

                if (isPresent == true) {

                    driver.findElement(By.xpath("//*[@id=\"attach-sidesheet-checkout-button\"]/span/input")).click();
                    Thread.sleep(300);

                }
            }
            CaptureScreen.cutPic("Case3_CheckOut","bin/screencapture/","jpg");


            String urlAfter = driver.getCurrentUrl();
            assertFalse(urlAfter == urlBefore);
            test = ChromeTestDemo.extent.startTest("TestCase3");
//            if (!urlAfter.equals(urlBefore)) {
//                test.log(LogStatus.PASS, "The Website successfully proceed to Submit order page.");
//                test.log(LogStatus.PASS, "<table><tr><td style=\"font-weight:bold\">Expected</td><td style=\"font-weight:bold\">Actual</td></tr><tr><td>Success Checkout</td><td>Success Checkout</td></tr></table>");
//            } else {
//                test.log(LogStatus.FAIL, "Website fail to proceed to submit order page.");
//            }


            if(urlAfter.equals("https://www.amazon.com/gp/buy/addressselect/handlers/display.html?hasWorkingJavascript=1")) {

                test.log(LogStatus.PASS, "The Website successfully proceed to Submit order page.");
                test.log(LogStatus.PASS, "<table><tr><td style=\"font-weight:bold\">Expected</td><td style=\"font-weight:bold\">Actual</td></tr><tr><td>Success Checkout</td><td>Success Checkout</td></tr></table>");
            }
           else {
               test.log(LogStatus.FAIL,urlAfter);
                test.log(LogStatus.FAIL, "Website fail to proceed to submit order page.");
            }
            ChromeTestDemo.extent.endTest(test);
            ChromeTestDemo.extent.flush();
            Thread.sleep(2000);
            driver.quit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
