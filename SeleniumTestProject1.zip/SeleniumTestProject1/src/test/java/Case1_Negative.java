import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.ExtentColor;

import static org.junit.Assert.assertEquals;


public class Case1_Negative {

    public ExtentTest test;

    public void TestCase1_Negative() throws InterruptedException {
        try {
            System.setProperty("webdriver.chrome.driver","/Users/wency/Desktop/chromedriver");
            WebDriver driver = new ChromeDriver();
            //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.get("https://www.amazon.com/");
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Negative_OpenAmazon","bin/screencapture/","jpg");

            WebElement searchBox=driver.findElement(By.linkText("Sign in"));
            searchBox.click();
            searchBox=driver.findElement(By.linkText("Create your Amazon account"));
            searchBox.click();
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Negative_OpenSignIn","bin/screencapture/","jpg");

            WebElement input_name = driver.findElement(By.name("customerName"));
            input_name.clear();
            input_name.sendKeys("Jing");//input name
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Negative_InputName","bin/screencapture/","jpg");

            WebElement input_email = driver.findElement(By.name("email"));
            input_email.clear();
            input_email.sendKeys("Jing@gmail.com");//input name
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Negative_InputEmail","bin/screencapture/","jpg");


            WebElement input_pw = driver.findElement(By.name("password"));
            input_pw.sendKeys("12345678");//input password
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Negative_InputPassword","bin/screencapture/","jpg");


            WebElement reinput_pw = driver.findElement(By.name("passwordCheck"));
            reinput_pw.sendKeys("125678");//input password
            Thread.sleep(500);
            CaptureScreen.cutPic("Case1_Negative_PasswordCheck","bin/screencapture/","jpg");




            test = ChromeTestDemo.extent.startTest("TestCase1_Negative");
            String urlBefore = driver.getCurrentUrl();
            driver.findElement(By.id("continue")).click();
            Thread.sleep(300);
            CaptureScreen.cutPic("Case1_Negative_Continue","bin/screencapture/","jpg");

            String urlAfter = driver.getCurrentUrl();
            assertEquals(urlBefore, urlAfter);

            Boolean pass = driver.findElements(By.xpath("//*[@id=\"a-autoid-0\"]/span/input")).size()>0;

//            if(pass==true){
//
//                test.log(LogStatus.PASS, "Website fail to identify a failed Registration");
//
//            }
//            else{
//                test.log(LogStatus.FAIL, "The Website prevent the Registration with invalid information.Expected: Success register. Actual:Invalid information");
//                System.out.println("Log Message:The Website prevent the Registration with invalid information");
//            }

            if(urlAfter.equals(urlBefore)){
                test.log(LogStatus.FAIL, "The Website prevent the Registration with invalid information");
                String[][] data = {
                        { "Expected", "Actual"},
                        { "Success Registration", "Password Mismatch"}

                };
                Markup m = MarkupHelper.createTable(data);

                test.log(LogStatus.FAIL, "<table><tr><td style=\"font-weight:bold\">Expected</td><td style=\"font-weight:bold\">Actual</td></tr><tr><td>Success Registration</td><td>Password Mismatch</td></tr></table>");
//                String text = "extent";
//                Markup n = MarkupHelper.createLabel(text, ExtentColor.BLUE);
//                test.log(LogStatus.FAIL,n.getMarkup());
                  System.out.println("Log Message:The Website prevent the Registration with invalid information");
            }
            else{
                test.log(LogStatus.FAIL, "Website fail to identify a failed Registration");
            }


            ChromeTestDemo.extent.endTest(test);
            ChromeTestDemo.extent.flush();
            driver.quit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
