import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.Assert.assertFalse;


public class Case2 {
    public static ExtentReports extent;
    public ExtentTest test;

    public void TestCase2() throws InterruptedException {
        Date dt=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        String date=sdf.format(dt);
        try {
            System.setProperty("webdriver.chrome.driver","/Users/wency/Desktop/chromedriver");
            WebDriver driver = new ChromeDriver();
            //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.get("https://www.amazon.com/");
            Thread.sleep(300);
            CaptureScreen.cutPic("Case2_OpenAmazon","bin/screencapture/","jpg");

            WebElement searchBox=driver.findElement(By.linkText("Sign in"));
            searchBox.click();
            Thread.sleep(300);
            CaptureScreen.cutPic("Case2_OpenSignIn","bin/screencapture/","jpg");

            WebElement input_email = driver.findElement(By.name("email"));
            input_email.clear();
            input_email.sendKeys("zhouruge2@163.com");//input name
            Thread.sleep(300);
            CaptureScreen.cutPic("Case2_InputEmail","bin/screencapture/","jpg");


            WebElement input_pw = driver.findElement(By.name("password"));
            input_pw.sendKeys("Aa11111111");//input password
            Thread.sleep(300);
            CaptureScreen.cutPic("Case2_Password","bin/screencapture/","jpg");


            String urlBefore = driver.getCurrentUrl();
            driver.findElement(By.id("signInSubmit")).click();
            String urlAfter = driver.getCurrentUrl();
            assertFalse(urlAfter == urlBefore);
            test = ChromeTestDemo.extent.startTest("TestCase2");
            if (!urlAfter.equals(urlBefore)) {
                test.log(LogStatus.PASS, "The Website allowed a successful sign in.");
                test.log(LogStatus.PASS, "<table><tr><td style=\"font-weight:bold\">Expected</td><td style=\"font-weight:bold\">Actual</td></tr><tr><td>Success Sign in</td><td>Success Sign in</td></tr></table>");
                CaptureScreen.cutPic("Case2_SuccessSignIn","bin/screencapture/","jpg");
            } else {
                test.log(LogStatus.FAIL, "Website fail to complete the sign in");
            }
            ChromeTestDemo.extent.endTest(test);
            ChromeTestDemo.extent.flush();
            Thread.sleep(2000);
            driver.quit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
